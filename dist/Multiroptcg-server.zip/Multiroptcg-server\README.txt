OPTCG 전용 서버 (Multiroptcg)
=============================

■ 켜기
  서버시작.bat 더블클릭. 뜨는 검은 창이 서버 본체 - 창을 닫으면 서버가 꺼짐.

■ 카드 데이터
  서버가 시작할 때마다 깃허브(OPTCG 레포)에서 카드DB/스크립트/코어를
  자동으로 받아온다. 인터넷 연결 필요. 갱신도 자동 - 재시작만 하면 됨.

■ 친구 접속시키기
  - 같은 공유기(LAN): 이 컴퓨터의 내부 IP로 접속
  - 외부 인터넷: 공유기 관리 페이지에서 TCP 7911, 7922 두 개를
    이 컴퓨터로 포트포워딩해야 함

■ 클라이언트(EDOPro) 쪽 설정
  config/configs.json 의 "servers" 배열에 추가:
    {
      "name": "OPTCG",
      "address": "서버IP",
      "roomaddress": "서버IP",
      "roomlistport": 7922,
      "duelport": 7911,
      "roomlistprotocol": "http"
    }

■ 주의
  - cacert.pem 지우지 말 것 (깃허브 HTTPS 인증서 번들)
  - tmp/, replays/ 폴더는 서버가 사용하는 작업 폴더
