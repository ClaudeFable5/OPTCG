@echo off
title Multiroptcg OPTCG server
cd /d "%~dp0"
set "SSL_CERT_FILE=%~dp0cacert.pem"
echo [OPTCG server starting - closing this window stops the server]
echo [first boot clones card data - may take 10-30 seconds]
multirole.exe
echo.
echo [server exited - check the log above if it crashed]
pause >nul
