@echo off
title Multiroptcg OPTCG server
cd /d "%~dp0"
set "SSL_CERT_FILE=%~dp0cacert.pem"
echo [OPTCG server starting - closing this window stops the server]
echo [card data bundled - boots offline, auto-updates when online]
echo [a blank window is normal - progress goes to boot.log]
multirole.exe > boot.log 2>&1
echo.
echo [server exited - last log:]
type boot.log
echo.
echo [if something is wrong, send the whole boot.log file]
pause >nul
