@echo off
title Multiroptcg OPTCG server
cd /d "%~dp0"
set "SSL_CERT_FILE=%~dp0cacert.pem"
echo [OPTCG server starting - closing this window stops the server]
echo [card data bundled - boots offline, auto-updates when online]
multirole.exe
echo.
echo [server exited - check the log above if it crashed]
pause >nul
