@echo off
chcp 65001 >nul
title Multiroptcg OPTCG server
cd /d "%~dp0"
set "SSL_CERT_FILE=%~dp0cacert.pem"
echo [OPTCG 서버 시작 - 이 창이 서버 본체, 창을 닫으면 서버가 꺼집니다]
echo [카드 데이터 동봉판 - 인터넷 없어도 켜지고, 있으면 자동 갱신]
echo [화면에 아무것도 안 떠도 정상 - 진행 상황은 boot.log 파일에 기록됩니다]
multirole.exe > boot.log 2>&1
echo.
echo [서버가 종료됐습니다 - 마지막 로그:]
type boot.log
echo.
echo [문제가 있으면 boot.log 파일을 통째로 보내주세요]
pause >nul
