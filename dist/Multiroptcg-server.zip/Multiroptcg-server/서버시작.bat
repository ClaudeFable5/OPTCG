@echo off
chcp 65001 >nul
title Multiroptcg OPTCG server
cd /d "%~dp0"
set "SSL_CERT_FILE=%~dp0cacert.pem"
echo [OPTCG 서버 시작 - 이 창이 서버 본체, 창을 닫으면 서버가 꺼집니다]
echo [첫 실행은 카드 데이터를 받느라 10~30초 걸릴 수 있습니다]
multirole.exe
echo.
echo [서버가 종료됐습니다. 비정상 종료라면 위 로그를 확인하세요.]
pause >nul
